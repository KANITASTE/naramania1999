# nara-mania

**奈良マニア（nara-mania）** は1998年〜2000年頃に作成された奈良の観光・文化紹介サイトです。  
27年の時を経てGitHub Pagesで公開できるよう復元・リニューアルしました。

## 🦌 サイトについて

奈良が大好きな「おだしー」さんが制作した個人サイト。  
法隆寺・東大寺・春日大社などの写真と解説、朱印カタログ、日記、チョコエッグ部屋など、  
2000年当時の個人サイトの雰囲気をそのままに現代のブラウザで閲覧できます。

## 📂 ファイル構成

```
index.html          # トップページ
menu.htm            # サイドメニュー（各コンテンツページで使用）

# バーチャル奈良（写真＋解説）
fpark.htm           # 奈良公園・興福寺・大仏殿
fkasuga.htm         # 東大寺二月堂・春日大社・ならまち
fhouryu.htm         # 法隆寺
ftousyo.htm         # 唐招提寺・薬師寺
fmurouhase.htm      # 室生寺・長谷寺
fyamanobe.htm       # 山の辺の道1
fyama.htm           # 山の辺の道2
fikoma.htm          # 生駒（宝山寺）
fodai.htm           # 大台ヶ原
ftenkawa.htm        # 天川
fsika.htm           # 鹿

# etc奈良
fmiyage.htm         # 奈良土産
syuin/in.htm        # 朱印カタログ（12社寺）

# nara-mania部屋
fnikki.htm          # 日記
fryokou.htm         # 奈良以外旅行譚（鎌倉）
CE/newpage1.htm     # ただいま夢中チョコエッグ部屋

# インタラクティブコンテンツ
bbs.html            # 掲示板（JavaScript版）
chat.html           # チャット（JavaScript版）
judge.html          # naramaniaチェック（40問クイズ）

img/                # 写真（JPG）・イラスト（GIF）
syuin/              # 朱印画像
CE/                 # チョコエッグ画像
icon/               # 掲示板アイコン
```

## 🌐 GitHub Pagesで公開する方法

1. このリポジトリをGitHubにプッシュ
2. リポジトリの **Settings** → **Pages**
3. **Source** を `Deploy from a branch` に設定
4. **Branch** を `main`、フォルダを `/ (root)` に設定
5. **Save** を押すと数分後に公開されます

公開URL例：`https://（ユーザー名）.github.io/（リポジトリ名）/`

## ✨ リニューアルポイント

- **文字コード**：Shift-JIS → UTF-8 に変換
- **レイアウト**：中央揃えに調整、レスポンシブ対応
- **画像リンク**：`img/`フォルダの画像を正しくリンク
- **フレームレイアウト**：`<frameset>`を `<iframe>` ベースに変換
- **廃止タグ対応**：`<blink>` をCSS animationで再現
- **掲示板**：CGIの代わりにJavaScript（sessionStorage）で動作
- **チャット**：JavaAppletの代わりにJavaScriptで当時の雰囲気を再現
- **naramaniaチェック**：40問のマニアック奈良クイズをランダム10問出題するシステムに拡充

## 📸 クレジット

写真・文章：おだしー（原著作者）  
技術的なリニューアル：Claude (Anthropic) によるアシスト  
制作年：1998〜2000年 → 2026年リニューアル

---

*奈良に行ったら、ぜひ鹿せんべいを買ってあげてください🦌*
